const map = L.map('map').setView([51.505, -0.09], 5); 

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);


function addMarker(lat, lon, cityName, countryCode) {
    const marker = L.marker([lat, lon]).addTo(map);

    
    fetch(`https://restcountries.com/v3.1/alpha/${countryCode}`)
        .then(response => response.json())
        .then(data => {
            if (data && data[0]) {
                const country = data[0];
                const countryName = country.name.common || "Unknown";
                const population = country.population || "Unknown";
                const area = country.area || "Unknown";

                marker.bindPopup(`
                    <b>${cityName}</b><br>
                    Latitude: ${lat}, Longitude: ${lon}<br>
                    Country: ${countryName}<br>
                    Population: ${population}<br>
                    Square: ${area} км²
                `).openPopup();
            }
        })
        .catch(error => {
            console.error('Error loading data:', error);
        });
}

addMarker(51.5074, -0.1278, 'London', 'GB'); 
addMarker(40.7128, -74.0060, 'New York', 'US'); 
addMarker(35.6895, 139.6917, 'Tokyo', 'JP'); 
addMarker(51.1694, 71.4491, 'Astana', 'KZ'); 
