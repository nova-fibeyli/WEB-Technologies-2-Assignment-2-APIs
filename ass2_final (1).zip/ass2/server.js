require("dotenv").config();
const express = require("express");
const path = require("path");
const axios = require("axios");

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, "public")));

// Serve index.html
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Fetch weather data
app.get("/api/weather", async (req, res) => {
  try {
    const city = req.query.city || "Astana"; // Default city
    const apiKey = process.env.OPENWEATHER_API_KEY;
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

    const response = await axios.get(url);
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch weather data" });
  }
});

// Fetch news data using NewsAPI.ai
app.get("/api/news", async (req, res) => {
  try {
    const apiKey = process.env.NEWS_API_AI_KEY;
    const query = req.query.q || "Kazakhstan";
    const url = `https://eventregistry.org/api/v1/article/getArticles?apiKey=${apiKey}&keyword=${query}&lang=eng`;

    const response = await axios.get(url);
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch news data" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
